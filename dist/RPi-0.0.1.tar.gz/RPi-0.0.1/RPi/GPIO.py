#pylint: disable=invalid-name, unused-argument, redefined-builtin
BOARD = "Board"
OUT = "Out"
IN = "In"
LOW = 0
HIGH = 1

def setmode(a):
    pass

def setup(a, b):
    pass

def output(a, b):
    pass

def input(a):
    return True

def cleanup():
    pass

def setwarnings(flag):
    pass
